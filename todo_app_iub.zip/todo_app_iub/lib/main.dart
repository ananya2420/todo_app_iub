import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo/models/TaskData.dart';
import 'package:todo/screens/tasks_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => TaskData(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepPurple),
          // If you want to use Material 3, you might need a different approach
          // as the Material 3 APIs might require a different setup.
        ),
        home: TasksScreen(),
      ),
    );
  }
}